"""CAGE-MATCH ADAPTER B — Fighter R's engine behind Fighter O's dialect.

Used in Round 1 (transmission chaos, O's native suite) and Round 3
(worker integration) so Fighter R can be driven by code that speaks the
original's interface.

Rule 5 compliance — every translation is a RENAME or a RESHAPE:
  * constructor kwargs:     name=/lease_ms/base_backoff_ms(ms)
                            -> namespace=/lease_seconds/backoff_base(s);
                            namespace is set to "sq:<name>" so the key
                            layout tests poke directly (prefix:job:<id>,
                            prefix:pending) lands on R's real keys.
  * enqueue return:         {"job_id","status","deduped"} -> (job_id, created)
  * claim return:           R's flat dict -> ClaimedJob (claim_id <- claim_token)
  * claim wait:             O's wait_timeout_s/poll_interval_s implemented
                            as a poll loop over R's immediate-return claim
                            (R has no blocking claim; O itself also polls)
  * ack/fail outcomes:      R's bool / "scheduled"/"dead"/"fenced"
                            -> Outcome enums; GONE vs STALE disambiguated
                            by reading the job hash R itself keeps
  * fail backoff return:    R schedules to an absolute time; backoff_ms is
                            recovered as (scheduled_for - updated_at), two
                            fields R's own fail script writes with the
                            same clock read
  * reap report:            R returns counts; the id lists O's dialect
                            wants are reconstructed by snapshotting the
                            expired candidates immediately before the
                            atomic reap and classifying them by the state
                            R left them in (the suites call reap with no
                            concurrent claimers, so this read-side
                            reconstruction is exact; documented)
  * reason vocabulary:      O's process_crash <-> R's process_crash_restart,
                            O's data_corruption <-> R's data_corruption_in_transit
  * error_trail/dlq_peek/stats/dlq_rate: reshaped reads of state R itself
                            stores (job hashes, dead list, done counter)

BORROWED INTERFACE VOCABULARY (flagged; the capability manifest still
credits these to Fighter O):
  * Reason/Outcome/ClaimedJob/RETRYABLE_DEFAULT definitions — pure
    dialect types with no engine behavior, copied so O-dialect callers
    can import them.
  * classify_exception — a pure exception->taxonomy mapping that never
    touches the queue; copied verbatim so sentinel_worker can run at all.

CAPABILITY GAPS (machinery Fighter R does not have; these raise
CapabilityGap loudly rather than fake an answer — Rule 5):
  * verify_invariants  (O's self-audit; declared at weigh-in)
  * requeue_from_dlq   (O's DLQ replay op; declared at weigh-in)
Counters R does not keep (enqueued, duplicate_enqueues, retries, reaped,
stale_acks, stale_fails, corrupt_payloads, orphan_refs) are ABSENT from
stats()["counters"] — never fabricated. R also has no payload-checksum
quarantine, no orphan quarantine, no escalate flag, and no jitter; those
scenarios fail visibly and are scored as capability differences.
"""
from __future__ import annotations

import errno
import json
import time
import uuid
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

from r_engine import TransmissionQueue as _RTQ

__all__ = ["Reason", "Outcome", "ClaimedJob", "TransmissionQueue"]


class CapabilityGap(NotImplementedError):
    """The emulated dialect requires machinery Fighter R does not have."""


# ---- O-dialect interface types (borrowed vocabulary; see module docstring)
class Reason(str, Enum):
    NETWORK_LATENCY = "network_latency"
    SERVICE_INTERRUPTION = "service_interruption"
    DATA_CORRUPTION = "data_corruption"
    PROCESS_CRASH = "process_crash"
    DB_CONNECTION_LOSS = "db_connection_loss"
    DISK_EXHAUSTION = "disk_exhaustion"
    UNCLASSIFIED = "unclassified"


RETRYABLE_DEFAULT: Dict[Reason, bool] = {
    Reason.NETWORK_LATENCY: True,
    Reason.SERVICE_INTERRUPTION: True,
    Reason.DATA_CORRUPTION: False,
    Reason.PROCESS_CRASH: True,
    Reason.DB_CONNECTION_LOSS: True,
    Reason.DISK_EXHAUSTION: True,
    Reason.UNCLASSIFIED: True,
}


class Outcome(str, Enum):
    OK = "ok"
    DEAD = "dead"
    SCHEDULED = "scheduled"
    GONE = "gone"
    STALE = "stale"


@dataclass(frozen=True)
class ClaimedJob:
    id: str
    payload: Dict[str, Any]
    attempt: int
    worker_id: str
    claim_id: str
    enqueued_at_ms: int
    lease_deadline_ms: int


_O2R = {
    Reason.NETWORK_LATENCY: "network_latency",
    Reason.SERVICE_INTERRUPTION: "service_interruption",
    Reason.DATA_CORRUPTION: "data_corruption_in_transit",
    Reason.PROCESS_CRASH: "process_crash_restart",
    Reason.DB_CONNECTION_LOSS: "db_connection_loss",
    Reason.DISK_EXHAUSTION: "disk_exhaustion",
    Reason.UNCLASSIFIED: "unclassified",
}
_R2O = {
    "network_latency": "network_latency",
    "service_interruption": "service_interruption",
    "data_corruption_in_transit": "data_corruption",
    "process_crash_restart": "process_crash",
    "db_connection_loss": "db_connection_loss",
    "disk_exhaustion": "disk_exhaustion",
    "unclassified": "unclassified",
}


class TransmissionQueue:
    """Fighter O's public surface; Fighter R's engine underneath."""

    def __init__(
        self,
        name: str = "v12",
        redis_url: Optional[str] = None,
        client: Optional[Any] = None,
        *,
        max_attempts: int = 5,
        lease_ms: int = 30_000,
        base_backoff_ms: int = 1_000,
        max_backoff_ms: int = 60_000,
        jitter_ms: int = 250,          # accepted; R backoff is deterministic
        promote_batch: int = 64,       # accepted; R promotes 100/claim
        error_trail_keep: Optional[int] = None,   # accepted; R keeps 20
        socket_timeout: float = 5.0,
        socket_connect_timeout: float = 2.0,
        health_check_interval: int = 30,   # accepted; not a knob R exposes
        max_connections: int = 50,
    ) -> None:
        if client is not None:
            raise CapabilityGap(
                "Fighter R's constructor builds its own pool from redis_url; "
                "injected-client mode is O-only."
            )
        self.name = name
        self.prefix = f"sq:{name}"
        self.max_attempts = int(max_attempts)
        self.lease_ms = int(lease_ms)
        self._q = _RTQ(
            redis_url=redis_url or "redis://localhost:6379/0",
            namespace=self.prefix,
            max_attempts=max_attempts,
            lease_seconds=lease_ms / 1000.0,
            backoff_base=base_backoff_ms / 1000.0,
            backoff_cap=max_backoff_ms / 1000.0,
            socket_timeout=socket_timeout,
            socket_connect_timeout=socket_connect_timeout,
            max_connections=max_connections,
        )
        self.r = self._q.r

    # ---------------------------------------------------------- helpers --
    def _k(self, suffix: str) -> str:
        return f"{self.prefix}:{suffix}"

    def _now_s(self) -> float:
        sec, usec = self.r.time()
        return float(sec) + float(usec) / 1_000_000.0

    def _now_ms(self) -> int:
        return int(self._now_s() * 1000)

    def _raw_hash(self, job_id: str) -> Dict[str, str]:
        return self.r.hgetall(self._q._job_key(job_id))

    # ---------------------------------------------------------- enqueue --
    def enqueue(
        self,
        payload: Dict[str, Any],
        job_id: Optional[str] = None,
        *,
        max_attempts: Optional[int] = None,
    ) -> Tuple[str, bool]:
        jid = job_id or uuid.uuid4().hex
        out = self._q.enqueue(jid, payload, max_attempts=max_attempts)
        return jid, not out["deduped"]

    # ------------------------------------------------------------ claim --
    def claim(
        self,
        worker_id: str,
        *,
        lease_ms: Optional[int] = None,
        wait_timeout_s: float = 0.0,
        poll_interval_s: float = 0.05,
    ) -> Optional[ClaimedJob]:
        lease_s = (lease_ms if lease_ms is not None else self.lease_ms) / 1000.0
        deadline = time.monotonic() + max(0.0, wait_timeout_s)
        while True:
            job = self._q.claim(worker_id, lease_seconds=lease_s)
            if job is not None:
                return ClaimedJob(
                    id=job["job_id"],
                    payload=job.get("payload") or {},
                    attempt=int(job["attempts"]),
                    worker_id=worker_id,
                    claim_id=job["claim_token"],
                    enqueued_at_ms=round(float(job.get("created_at", 0)) * 1000),
                    lease_deadline_ms=round(float(job.get("lease_expires_at", 0)) * 1000),
                )
            if time.monotonic() >= deadline:
                return None
            time.sleep(min(poll_interval_s,
                           max(0.0, deadline - time.monotonic())))

    # -------------------------------------------------------------- ack --
    def ack(self, job: ClaimedJob) -> Outcome:
        if self._q.ack(job.id, job.claim_id):
            return Outcome.OK
        h = self._raw_hash(job.id)
        if not h:
            return Outcome.GONE
        if h.get("status") == "done":
            return Outcome.GONE       # already completed; O's retry-safe shape
        return Outcome.STALE

    # ------------------------------------------------------------- fail --
    def fail(
        self,
        job: ClaimedJob,
        reason: Reason,
        detail: str,
        *,
        retryable: Optional[bool] = None,
    ) -> Tuple[Outcome, Optional[int]]:
        if retryable is None:
            retryable = RETRYABLE_DEFAULT[reason]
        out = self._q.fail(job.id, job.claim_id, _O2R[reason], str(detail),
                           retryable=bool(retryable))
        if out == "scheduled":
            h = self._raw_hash(job.id)
            backoff_ms = round(
                (float(h["scheduled_for"]) - float(h["updated_at"])) * 1000
            )
            return Outcome.SCHEDULED, backoff_ms
        if out == "dead":
            return Outcome.DEAD, None
        h = self._raw_hash(job.id)
        if not h:
            return Outcome.GONE, None
        return Outcome.STALE, None

    # ------------------------------------------------------------- reap --
    def reap_expired(self, batch: int = 100) -> Dict[str, List[str]]:
        # Snapshot the expired candidates R's atomic reap is about to act
        # on, then classify by the state it left them in. See module
        # docstring for the exactness conditions.
        now = self._now_s()
        candidates = [
            x for x in self.r.zrangebyscore(
                self._k("processing"), "-inf", now, start=0, num=batch)
        ]
        counts = self._q.reap_expired(limit=batch)
        report: Dict[str, List[str]] = {"requeued": [], "dead": [], "orphaned": []}
        for jid in candidates:
            st = self.r.hget(self._q._job_key(jid), "status")
            if st == "dead":
                report["dead"].append(jid)
            elif st in ("pending", "processing", "scheduled"):
                report["requeued"].append(jid)
            else:
                report["orphaned"].append(jid)
        # Trust R's atomic counts over the snapshot if anything raced.
        if (len(report["requeued"]) != counts["requeued"]
                or len(report["dead"]) != counts["dead"]):
            report["_counts_from_engine"] = counts  # type: ignore[assignment]
        return report

    # ---------------------------------------------------- observability --
    def stats(self) -> Dict[str, Any]:
        now = self._now_ms()
        now_s = now / 1000.0
        p = self.r.pipeline(transaction=False)
        p.llen(self._k("pending"))
        p.zcard(self._k("scheduled"))
        p.zcount(self._k("scheduled"), "-inf", now_s)
        p.zcard(self._k("processing"))
        p.zcount(self._k("processing"), "-inf", now_s)
        p.llen(self._k("dead"))
        p.get(self._k("done_count"))
        p.lindex(self._k("pending"), 0)   # R enqueues RPUSH: head = oldest
        p.llen(self._k("orphans"))        # R never writes this; 0 = truthful
        r = p.execute()

        oldest_pending_age_ms = None
        if r[7] is not None:
            created = self.r.hget(self._q._job_key(r[7]), "created_at")
            if created is not None:
                oldest_pending_age_ms = now - round(float(created) * 1000)

        dead_ids = self.r.lrange(self._k("dead"), 0, -1)
        dead_reasons: Dict[str, int] = {}
        dead_last_hour = 0
        for jid in dead_ids:
            h = self._raw_hash(jid)
            dr = _R2O.get(h.get("dead_reason", ""), h.get("dead_reason", ""))
            if dr:
                dead_reasons[dr] = dead_reasons.get(dr, 0) + 1
            died = h.get("died_at")
            if died is not None and (now_s - float(died)) <= 3600.0:
                dead_last_hour += 1

        counters: Dict[str, Any] = {"completed": int(r[6] or 0)}
        # Counters R does not keep are deliberately ABSENT, never invented.
        return {
            "now_ms": now,
            "depth_ready": r[0] + r[2],
            "pending": r[0],
            "scheduled": r[1],
            "scheduled_due": r[2],
            "processing": r[3],
            "processing_overdue": r[4],
            "dead": r[5],
            "dead_last_hour": dead_last_hour,
            "oldest_pending_age_ms": oldest_pending_age_ms,
            "orphan_refs": r[8],
            "counters": counters,
            "dead_reasons": dead_reasons,
        }

    def dlq_rate(self, window_s: int = 3600) -> Dict[str, float]:
        now_s = self._now_s()
        n = 0
        for jid in self.r.lrange(self._k("dead"), 0, -1):
            died = self.r.hget(self._q._job_key(jid), "died_at")
            if died is not None and (now_s - float(died)) <= window_s:
                n += 1
        return {"window_s": float(window_s), "count": float(n),
                "per_minute": n / (window_s / 60.0)}

    def error_trail(self, job_id: str) -> List[Dict[str, Any]]:
        h = self._raw_hash(job_id)
        if not h or "error_trail" not in h:
            return []
        try:
            trail = json.loads(h["error_trail"])
        except (ValueError, TypeError):
            return []
        out = []
        for e in reversed(trail):            # R oldest-first -> O newest-first
            out.append({
                "attempt": e.get("attempt"),
                "reason": _R2O.get(e.get("reason"), e.get("reason")),
                "detail": e.get("error"),
                "at_ms": round(float(e.get("at", 0)) * 1000),
            })
        return out

    def dlq_peek(self, n: int = 10) -> List[Dict[str, Any]]:
        ids = self.r.lrange(self._k("dead"), -n, -1)[::-1]  # newest first
        out = []
        for jid in ids:
            h = self._raw_hash(jid)
            job: Dict[str, Any] = dict(h)
            job["id"] = h.get("job_id", jid)
            if "dead_reason" in h:
                job["dead_reason"] = _R2O.get(h["dead_reason"], h["dead_reason"])
            # NOTE: no "escalate" key — Fighter R has no escalate flag.
            job["error_trail"] = self.error_trail(jid)
            out.append(job)
        return out

    def requeue_from_dlq(self, job_id: str) -> Outcome:
        raise CapabilityGap(
            "Fighter R has no DLQ replay operation (requeue_from_dlq is "
            "O-only; declared at weigh-in)."
        )

    def verify_invariants(self) -> Dict[str, Any]:
        raise CapabilityGap(
            "Fighter R has no self-audit machinery (verify_invariants is "
            "O-only; declared at weigh-in)."
        )

    # ----------------------------------------------------------- helpers --
    @staticmethod
    def classify_exception(exc: BaseException) -> Reason:
        # Borrowed verbatim from Fighter O (pure vocabulary helper).
        name = type(exc).__name__.lower()
        text = str(exc).lower()
        if isinstance(exc, TimeoutError) or "timeout" in name:
            return Reason.NETWORK_LATENCY
        if getattr(exc, "errno", None) == errno.ENOSPC or "no space left" in text:
            return Reason.DISK_EXHAUSTION
        if name in ("operationalerror", "interfaceerror"):
            return Reason.DB_CONNECTION_LOSS
        if isinstance(exc, ConnectionError) or "connection" in name:
            return Reason.SERVICE_INTERRUPTION
        if name in ("jsondecodeerror", "unicodedecodeerror"):
            return Reason.DATA_CORRUPTION
        return Reason.UNCLASSIFIED

    def close(self) -> None:
        self.r.close()
