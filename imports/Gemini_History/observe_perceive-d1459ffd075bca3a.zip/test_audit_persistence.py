"""
Audit persistence (WAL) + widened PERCEIVE chain-hash coverage.

Item 2 — Write-ahead persistence: every sealed audit entry is durably written to a JSONL
         file, and a fresh ledger/system reconstructs the full chain (entries + chain_head)
         from disk on construction, so the audit trail survives a process restart. On-disk
         tampering is caught on reload.

Item 3 — Widened PERCEIVE hash: the governance chain hash now binds the ENTIRE
         decision-relevant entry (request_snapshot + policy_outputs + manifest fields, not
         just audit_id/timestamp/gates/final_verdict), so tampering with any of those fields
         is detected.

Default behavior (no wal path/dir) stays pure in-memory — asserted for backward compat.
"""

from datetime import datetime, timezone, timedelta

from observe_consolidated import (
    VitalsSnapshot,
    PatientContext,
    ImmutableAuditLedger as ObserveLedger,
)
from clinical_governance_system import build_single_hospital_system

FIXED_TS = datetime(2026, 6, 18, 12, 0, 0, tzinfo=timezone.utc)


def _stable(pc, t=FIXED_TS):
    return VitalsSnapshot.from_context(pc, t, 110, 99, 22, 37.0)


def _critical(pc, t=FIXED_TS):
    return VitalsSnapshot.from_context(pc, t, 170, 80, 46, 39.6)


# ============================================================================
# Item 2 — OBSERVE ledger persistence (direct)
# ============================================================================

def test_observe_wal_writes_and_reloads(tmp_path):
    p = str(tmp_path / "obs.jsonl")
    led = ObserveLedger(wal_path=p)
    led.append("p1", "clinical_assessment", {"risk": 0.1})
    led.append("p1", "clinical_assessment", {"risk": 0.2})
    led.append("p2", "clinical_assessment", {"risk": 0.9})

    # Fresh ledger on the same path reconstructs the chain from disk.
    reloaded = ObserveLedger(wal_path=p)
    assert len(reloaded.entries) == 3
    assert reloaded.verify_integrity() is True
    # chain_head is restored so appends continue the SAME chain.
    assert reloaded.chain_head == led.chain_head


def test_observe_reload_continues_chain(tmp_path):
    p = str(tmp_path / "obs.jsonl")
    led = ObserveLedger(wal_path=p)
    led.append("p1", "clinical_assessment", {"risk": 0.1})

    reloaded = ObserveLedger(wal_path=p)
    reloaded.append("p1", "clinical_assessment", {"risk": 0.3})  # append after restart
    assert len(reloaded.entries) == 2
    assert reloaded.verify_integrity() is True
    # The file now holds both entries.
    assert sum(1 for _ in open(p)) == 2


def test_observe_on_disk_tamper_detected_after_reload(tmp_path):
    import json
    p = str(tmp_path / "obs.jsonl")
    led = ObserveLedger(wal_path=p)
    led.append("p1", "clinical_assessment", {"risk_score": 0.1})
    led.append("p1", "clinical_assessment", {"risk_score": 0.2})

    # Corrupt the persisted payload of the first record on disk.
    lines = [json.loads(l) for l in open(p) if l.strip()]
    lines[0]["data"]["risk_score"] = 0.999
    with open(p, "w") as f:
        for rec in lines:
            f.write(json.dumps(rec, sort_keys=True, default=str) + "\n")

    reloaded = ObserveLedger(wal_path=p)
    assert reloaded.verify_integrity() is False


def test_observe_default_is_in_memory(tmp_path):
    led = ObserveLedger()  # no wal_path
    assert led._wal is None
    led.append("p1", "a", {"x": 1})
    assert led.verify_integrity() is True


# ============================================================================
# Item 2 — Full system persistence (both chains survive restart)
# ============================================================================

def test_system_persists_both_chains(tmp_path):
    d = str(tmp_path / "wal")
    sys1 = build_single_hospital_system(audit_wal_dir=d)
    # Two distinct critical patients -> each escalates -> two PERCEIVE entries; every
    # reading produces an OBSERVE entry.
    sys1.process_vitals(_critical(PatientContext("A", age_months=24), FIXED_TS))
    sys1.process_vitals(_critical(PatientContext("B", age_months=24), FIXED_TS + timedelta(minutes=1)))

    n_obs = len(sys1.observe.audit_ledger.entries)
    n_perc = len(sys1.perceive.audit_ledger.entries)
    assert n_obs == 2 and n_perc == 2

    # Restart: a brand-new system pointed at the same directory reloads BOTH chains.
    sys2 = build_single_hospital_system(audit_wal_dir=d)
    assert len(sys2.observe.audit_ledger.entries) == n_obs
    assert len(sys2.perceive.audit_ledger.entries) == n_perc
    status = sys2.verify_all_audits()
    assert status == {"observe_chain_valid": True, "perceive_chain_valid": True}


def test_system_default_no_persistence():
    sys = build_single_hospital_system()  # no wal dir
    assert sys.observe.audit_ledger._wal is None
    assert sys.perceive.audit_ledger._wal is None
    sys.process_vitals(_critical(PatientContext("A", age_months=24)))
    assert sys.verify_all_audits()["observe_chain_valid"] is True


# ============================================================================
# Item 3 — Widened PERCEIVE hash covers the full decision-relevant entry
# ============================================================================

def _system_with_one_escalation():
    sys = build_single_hospital_system()
    sys.process_vitals(_critical(PatientContext("crit", age_months=24)))
    assert sys.perceive.verify_audit_integrity() is True
    assert len(sys.perceive.audit_ledger.entries) >= 1
    return sys


def test_perceive_request_snapshot_tamper_now_detected():
    # request_snapshot was NOT in the old hash; the widened hash must catch this.
    sys = _system_with_one_escalation()
    e = sys.perceive.audit_ledger.entries[0]
    assert isinstance(e.request_snapshot, dict) and e.request_snapshot  # non-empty
    e.request_snapshot["subject_id"] = "TAMPERED"
    assert sys.perceive.verify_audit_integrity() is False


def test_perceive_policy_outputs_tamper_now_detected():
    sys = _system_with_one_escalation()
    e = sys.perceive.audit_ledger.entries[0]
    assert e.policy_outputs  # non-empty
    # Flip an approval inside the recorded gate outcomes.
    e.policy_outputs[0]["approved"] = not e.policy_outputs[0]["approved"]
    assert sys.perceive.verify_audit_integrity() is False


def test_perceive_manifest_hash_tamper_now_detected():
    sys = _system_with_one_escalation()
    sys.perceive.audit_ledger.entries[0].manifest_hash = "deadbeef" * 8
    assert sys.perceive.verify_audit_integrity() is False


def test_perceive_final_verdict_tamper_still_detected():
    # Regression: a field that was already covered must remain covered.
    sys = _system_with_one_escalation()
    sys.perceive.audit_ledger.entries[0].final_verdict = {"approved": False, "tampered": True}
    assert sys.perceive.verify_audit_integrity() is False


def test_perceive_clean_chain_still_verifies():
    sys = _system_with_one_escalation()
    assert sys.perceive.verify_audit_integrity() is True
