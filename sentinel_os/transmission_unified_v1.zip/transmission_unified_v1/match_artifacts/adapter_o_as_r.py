"""CAGE-MATCH ADAPTER A — Fighter O's engine behind Fighter R's dialect.

Used in Round 2 (ingress live fire) so Fighter O can be driven by
api_server_v2.py + its suite, which speak the rebuild's interface.

Rule 5 compliance — every translation is a RENAME or a RESHAPE:
  * constructor kwargs:      namespace=/lease_seconds/backoff_base(s)
                             -> name=/lease_ms/base_backoff_ms(ms)
  * enqueue return:          (job_id, created) -> {"job_id","status","deduped"}
  * claim return:            ClaimedJob -> flat dict with claim_token
  * claim_token:             opaque encoding of O's (worker_id, claim_id) fence
  * fail/ack outcomes:       Outcome enum -> "scheduled"/"dead"/"fenced" / bool
  * reason vocabulary:       R's process_crash_restart <-> O's process_crash,
                             R's data_corruption_in_transit <-> O's data_corruption
  * stats/get_job:           reshaped reads of O's own stored state
  * jitter:                  R's dialect declares deterministic backoff
                             (base * 2^(n-1), capped, no jitter), so the O
                             engine runs with jitter_ms=0 here.

DECLARED STRUCTURAL DIFFERENCES (cannot be translated without changing
O's behavior — reported per Rule 5, NOT papered over):
  1. O deletes the job hash on ack. There is no "done" record, so
     get_job() of a completed job returns None (-> ingress 404), and a
     re-enqueue after completion creates a NEW job instead of deduping.
  2. O discards ack results; the result= kwarg cannot be persisted.
  3. O has no lease renewal: heartbeat() raises CapabilityGap.
Nothing here fabricates state O does not hold.
"""
from __future__ import annotations

import json
import time
import uuid
from typing import Any, Dict, Optional

from o_engine import (
    ClaimedJob,
    Outcome,
    Reason,
    TransmissionQueue as _OTQ,
)


class CapabilityGap(NotImplementedError):
    """Raised when the emulated dialect requires machinery the underlying
    fighter does not have. Deliberately loud (Rule 5: never silently skip,
    never silently resolve)."""


# Reason vocabulary: R name -> O enum, and O value -> R name.
_R2O = {
    "network_latency": Reason.NETWORK_LATENCY,
    "service_interruption": Reason.SERVICE_INTERRUPTION,
    "data_corruption_in_transit": Reason.DATA_CORRUPTION,
    "process_crash_restart": Reason.PROCESS_CRASH,
    "db_connection_loss": Reason.DB_CONNECTION_LOSS,
    "disk_exhaustion": Reason.DISK_EXHAUSTION,
    "unclassified": Reason.UNCLASSIFIED,
}
_O2R = {
    "network_latency": "network_latency",
    "service_interruption": "service_interruption",
    "data_corruption": "data_corruption_in_transit",
    "process_crash": "process_crash_restart",
    "db_connection_loss": "db_connection_loss",
    "disk_exhaustion": "disk_exhaustion",
    "unclassified": "unclassified",
}

_TOKEN_SEP = "\x1f"  # unit separator: cannot appear in worker ids used here


class TransmissionQueue:
    """Fighter R's public surface; Fighter O's engine underneath."""

    def __init__(
        self,
        redis_url: str = "redis://localhost:6379/0",
        namespace: str = "tq",
        max_attempts: int = 3,
        lease_seconds: float = 30.0,
        backoff_base: float = 0.5,
        backoff_cap: float = 30.0,
        socket_timeout: float = 2.0,
        socket_connect_timeout: float = 2.0,
        max_connections: int = 64,
    ) -> None:
        self.ns = namespace
        self.max_attempts = int(max_attempts)
        self.lease_seconds = float(lease_seconds)
        self._q = _OTQ(
            name=namespace,                      # O prefix becomes sq:<namespace>
            redis_url=redis_url,
            max_attempts=max_attempts,
            lease_ms=int(lease_seconds * 1000),
            base_backoff_ms=int(backoff_base * 1000),
            max_backoff_ms=int(backoff_cap * 1000),
            jitter_ms=0,                         # R dialect: deterministic backoff
            socket_timeout=socket_timeout,
            socket_connect_timeout=socket_connect_timeout,
            max_connections=max_connections,
        )
        self.r = self._q.r

    # ---------------------------------------------------------- helpers --
    def _hash(self, job_id: str) -> Dict[str, str]:
        raw = self.r.hgetall(f"{self._q.prefix}:job:{job_id}")
        return {k.decode(): v.decode() for k, v in raw.items()}

    def _trail_r_shape(self, job_id: str) -> list:
        """O stores the error trail newest-first in a side list with
        {attempt, reason, detail, worker, at_ms}; R's dialect wants it
        oldest-first with {attempt, reason, error, at}. Pure reshape."""
        raw = self.r.lrange(f"{self._q.prefix}:errors:{job_id}", 0, -1)
        entries = [json.loads(x) for x in raw][::-1]
        return [
            {
                "attempt": e.get("attempt"),
                "reason": _O2R.get(e.get("reason"), e.get("reason")),
                "error": e.get("detail"),
                "at": (e.get("at_ms") or 0) / 1000.0,
            }
            for e in entries
        ]

    # ----------------------------------------------------- producer side --
    def enqueue(
        self,
        job_id: str,
        payload: Dict[str, Any],
        max_attempts: Optional[int] = None,
    ) -> Dict[str, Any]:
        jid, created = self._q.enqueue(
            payload, job_id=job_id, max_attempts=max_attempts
        )
        if created:
            return {"job_id": jid, "status": "pending", "deduped": False}
        status = self._hash(jid).get("status", "pending")
        return {"job_id": jid, "status": status, "deduped": True}

    def get_job(self, job_id: str) -> Optional[Dict[str, Any]]:
        h = self._hash(job_id)
        if not h:
            # STRUCTURAL: O deletes completed jobs; a finished job is
            # indistinguishable from one that never existed.
            return None
        trail = self._trail_r_shape(job_id)
        job: Dict[str, Any] = {
            "job_id": h.get("id", job_id),
            "status": h.get("status"),
            "attempts": int(h.get("attempts", 0)),
            "max_attempts": int(h.get("max_attempts", 0)),
            "created_at": int(h.get("enqueued_at_ms", 0)) / 1000.0,
            "payload": json.loads(h["payload"]) if "payload" in h else None,
        }
        updated_ms = None
        for f in ("dead_at_ms", "next_retry_at_ms", "claimed_at_ms"):
            if h.get(f):
                updated_ms = int(h[f])
                break
        if updated_ms is None and trail:
            updated_ms = int(trail[-1]["at"] * 1000)
        job["updated_at"] = (updated_ms or int(h.get("enqueued_at_ms", 0))) / 1000.0
        if trail:
            job["error_trail"] = trail
            job["last_error"] = trail[-1]["error"]
        st = job["status"]
        if st == "scheduled" and h.get("next_retry_at_ms"):
            job["scheduled_for"] = int(h["next_retry_at_ms"]) / 1000.0
        elif st == "processing":
            job["claimed_by"] = h.get("claimed_by")
            if h.get("lease_deadline_ms"):
                job["lease_expires_at"] = int(h["lease_deadline_ms"]) / 1000.0
        elif st == "dead":
            job["dead_reason"] = _O2R.get(h.get("dead_reason"), h.get("dead_reason"))
            if h.get("dead_at_ms"):
                job["died_at"] = int(h["dead_at_ms"]) / 1000.0
        return job

    def stats(self) -> Dict[str, Any]:
        s = self._q.stats()
        oldest_ms = s.get("oldest_pending_age_ms")
        return {
            "pending": s["pending"],
            "scheduled": s["scheduled"],
            "processing": s["processing"],
            "done": int(s["counters"].get("completed", 0)),
            "dead": s["dead"],
            "oldest_pending_age_s": (oldest_ms / 1000.0) if oldest_ms is not None else None,
        }

    def ping(self) -> bool:
        return bool(self.r.ping())

    # ------------------------------------------------------- worker side --
    def claim(self, worker_id: str,
              lease_seconds: Optional[float] = None) -> Optional[Dict[str, Any]]:
        lease_ms = int((lease_seconds or self.lease_seconds) * 1000)
        job = self._q.claim(worker_id, lease_ms=lease_ms, wait_timeout_s=0.0)
        if job is None:
            return None
        token = f"{job.worker_id}{_TOKEN_SEP}{job.claim_id}"
        return {
            "job_id": job.id,
            "payload": job.payload,
            "attempts": job.attempt,
            "max_attempts": self._hash(job.id).get("max_attempts"),
            "status": "processing",
            "claimed_by": job.worker_id,
            "claim_token": token,
            "lease_expires_at": job.lease_deadline_ms / 1000.0,
            "created_at": job.enqueued_at_ms / 1000.0,
        }

    def _fence(self, job_id: str, claim_token: str) -> ClaimedJob:
        worker_id, _, claim_id = claim_token.partition(_TOKEN_SEP)
        return ClaimedJob(id=job_id, payload={}, attempt=0, worker_id=worker_id,
                          claim_id=claim_id, enqueued_at_ms=0, lease_deadline_ms=0)

    def heartbeat(self, job_id: str, claim_token: str,
                  lease_seconds: Optional[float] = None) -> bool:
        raise CapabilityGap(
            "Fighter O has no lease-renewal mechanism (declared at weigh-in): "
            "an O lease can only expire, never be extended."
        )

    def ack(self, job_id: str, claim_token: str,
            result: Optional[Dict[str, Any]] = None) -> bool:
        # STRUCTURAL: O discards results on completion; `result` cannot be
        # persisted without changing O's write path.
        out = self._q.ack(self._fence(job_id, claim_token))
        return out is Outcome.OK

    def fail(self, job_id: str, claim_token: str, reason: str, error: str,
             retryable: bool = True) -> str:
        o_reason = _R2O.get(reason, Reason.UNCLASSIFIED)
        outcome, _backoff = self._q.fail(
            self._fence(job_id, claim_token), o_reason, error, retryable=retryable
        )
        if outcome is Outcome.SCHEDULED:
            return "scheduled"
        if outcome is Outcome.DEAD:
            return "dead"
        return "fenced"

    def reap_expired(self, limit: int = 100) -> Dict[str, int]:
        report = self._q.reap_expired(batch=limit)
        return {"requeued": len(report["requeued"]), "dead": len(report["dead"])}

    # ------------------------------------------------------- maintenance --
    def flush_namespace(self) -> int:
        n = 0
        for key in self.r.scan_iter(match=f"{self._q.prefix}:*", count=500):
            self.r.delete(key)
            n += 1
        return n
