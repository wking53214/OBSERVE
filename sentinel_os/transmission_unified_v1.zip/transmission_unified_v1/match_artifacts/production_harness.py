"""ARENA SCAFFOLDING — stand-in for the Iceberg project's
production_harness.py, which is not part of the cage-match kit.

This implements, against REAL Postgres, exactly the behavioral contract
that sentinel_worker.py and its suite (and the worker verification
report) document for IcebergProductionHarness.process_call:

  * ledger dedup on call_sid:  sid already recorded -> {"error": "duplicate_sid"}
  * parse failures (unrecognized Twilio status, missing sid, bad duration)
      -> {"error": "Failed to parse call: ..."}  (never touches the ledger)
  * ungoverned calls (below governance_trigger) -> success, NO ledger row
  * governed calls with no Claude client configured -> the documented
      fail-closed path: claude_safe=False, decision IS durably recorded
  * append_decision raising -> {"ledger_write_failed": True, ...}
      (reported, not raised — the worker decides ack/fail from the shape)
  * process_call never raises for these shapes; it reports.

Shared identically by BOTH fighters. Not part of either fighter's code.
The queue code under test is the byte-verified original in each corner.
"""
from __future__ import annotations

import json
import threading
from typing import Any, Dict, List, Optional

import psycopg2

# The subset of Twilio call statuses the parser accepts (the real
# TWILIO_TO_ICEBERG mapping's keys, per the worker suite's expectations:
# "completed" parses; "ringing" does not).
TWILIO_TO_ICEBERG = {
    "completed": "call_completed",
    "busy": "call_busy",
    "failed": "call_failed",
    "no-answer": "call_no_answer",
}

GOVERNANCE_TRIGGER_DURATION_S = 30  # >= this -> governed


class Ledger:
    """Postgres-backed decision ledger. Dedup key: input_data->>'call_sid'
    (unique index in the schema)."""

    def __init__(self, dsn: Dict[str, Any]) -> None:
        self._dsn = dsn
        self._lock = threading.Lock()
        self._conn = psycopg2.connect(**dsn)
        self._conn.autocommit = True

    def _cursor(self):
        try:
            return self._conn.cursor()
        except psycopg2.InterfaceError:
            self._conn = psycopg2.connect(**self._dsn)
            self._conn.autocommit = True
            return self._conn.cursor()

    def sid_exists(self, call_sid: str) -> bool:
        with self._lock:
            cur = self._cursor()
            cur.execute(
                "SELECT 1 FROM ledger_entries WHERE input_data->>'call_sid' = %s LIMIT 1",
                (call_sid,),
            )
            row = cur.fetchone()
            cur.close()
            return row is not None

    def append_decision(self, input_data: Dict[str, Any],
                        decision: Dict[str, Any]) -> int:
        """Insert one decision row; COMMIT is the durability point."""
        with self._lock:
            cur = self._cursor()
            cur.execute(
                "INSERT INTO ledger_entries (input_data, decision) "
                "VALUES (%s, %s) RETURNING id",
                (json.dumps(input_data), json.dumps(decision)),
            )
            rid = cur.fetchone()[0]
            cur.close()
            return rid

    def get_decisions(self, limit: int = 50) -> List[Dict[str, Any]]:
        with self._lock:
            cur = self._cursor()
            cur.execute(
                "SELECT id, input_data, decision, created_at FROM ledger_entries "
                "ORDER BY id DESC LIMIT %s", (limit,),
            )
            rows = cur.fetchall()
            cur.close()
        return [
            {"id": r[0], "input_data": r[1], "decision": r[2],
             "created_at": r[3].isoformat()}
            for r in rows
        ]

    def close(self) -> None:
        try:
            self._conn.close()
        except Exception:
            pass


class IcebergProductionHarness:
    """Behavioral stand-in for the real harness: parse -> dedup check ->
    governance gate -> (fail-closed) governor -> ledger commit."""

    def __init__(self, config: Dict[str, Any]) -> None:
        self.config = config
        self.ledger = Ledger({
            "host": config.get("postgres_host", "localhost"),
            "port": config.get("postgres_port", 5432),
            "dbname": config.get("postgres_db", "iceberg"),
            "user": config.get("postgres_user", "iceberg"),
            "password": config.get("postgres_password", "iceberg"),
        })
        self.claude_api_key: Optional[str] = config.get("claude_api_key")
        self.cassette_domain = config.get("cassette_domain", "ivr")

    # ----------------------------------------------------------- parse --
    @staticmethod
    def _parse(payload: Dict[str, Any]) -> Dict[str, Any]:
        sid = payload.get("sid")
        if not sid or not isinstance(sid, str):
            raise ValueError("Failed to parse call: missing or invalid sid")
        status = payload.get("status", "completed")
        if status not in TWILIO_TO_ICEBERG:
            raise ValueError(
                f"Failed to parse call: unrecognized status {status!r}"
            )
        duration = payload.get("duration", 0)
        try:
            duration = int(duration)
        except (TypeError, ValueError):
            raise ValueError(
                f"Failed to parse call: duration {payload.get('duration')!r} "
                f"is not an integer"
            )
        return {"call_sid": sid, "intent": TWILIO_TO_ICEBERG[status],
                "duration": duration, "caller": payload.get("from")}

    # ---------------------------------------------------------- process --
    def process_call(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Never raises for contract shapes; reports via the result dict."""
        try:
            parsed = self._parse(payload)
        except ValueError as exc:
            return {"error": str(exc), "governed": False,
                    "ledger_write_failed": False}

        sid = parsed["call_sid"]

        # Ledger dedup on call_sid: a redelivered, already-recorded job is
        # proof the crash-between-commit-and-ack path worked as designed.
        if self.ledger.sid_exists(sid):
            return {"error": "duplicate_sid", "governed": None,
                    "ledger_write_failed": False}

        governed = parsed["duration"] >= GOVERNANCE_TRIGGER_DURATION_S
        if not governed:
            # Below the governance trigger: complete with no ledger row.
            return {"governed": False, "governance_approved": None,
                    "governance_blocked": None, "intent": parsed["intent"],
                    "ledger_write_failed": False}

        # Governed. No Claude client configured -> documented fail-closed
        # path: safe=False, but the decision IS durably recorded.
        if self.claude_api_key:
            claude_safe = True   # (never taken in these suites)
            rationale = "governor approved"
        else:
            claude_safe = False
            rationale = "No API client configured; failing closed"

        decision = {
            "claude_safe": claude_safe,
            "rationale": rationale,
            "intent": parsed["intent"],
            "cassette_domain": self.cassette_domain,
        }
        input_data = {"call_sid": sid, "duration": parsed["duration"],
                      "caller": parsed["caller"], "intent": parsed["intent"]}
        try:
            self.ledger.append_decision(input_data, decision)
        except Exception as exc:
            # THE F-2 SHAPE: a governance decision happened but was NOT
            # durably recorded. Reported, never swallowed, never raised.
            return {"governed": True, "ledger_write_failed": True,
                    "claude_safe": claude_safe, "intent": parsed["intent"],
                    "ledger_error": f"{type(exc).__name__}: {exc}"}

        return {"governed": True, "ledger_write_failed": False,
                "claude_safe": claude_safe,
                "governance_approved": claude_safe,
                "governance_blocked": not claude_safe,
                "intent": parsed["intent"]}

    def shutdown(self) -> None:
        self.ledger.close()
