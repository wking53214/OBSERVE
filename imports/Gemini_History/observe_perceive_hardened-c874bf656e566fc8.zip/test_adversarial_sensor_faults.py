"""Tests for the adversarial sensor-fault suite (robustness validation)."""

import unittest

from adversarial_sensor_faults import AdversarialSensorTestSuite, FAULT_CASES


class TestAdversarialSensorFaults(unittest.TestCase):
    """Verify OBSERVE degrades safely under pathological sensor inputs."""

    def setUp(self):
        self.suite = AdversarialSensorTestSuite()

    def test_non_finite_inputs_escalate(self):
        """NaN, Inf, out-of-range values must always escalate (safety default)."""
        non_finite_cases = [
            "nan_oxygen",
            "inf_heart_rate",
            "out_of_range_temp",
        ]
        for case_name in non_finite_cases:
            with self.subTest(case=case_name):
                case = next(c for c in FAULT_CASES if c.name == case_name)
                result = self.suite.evaluate_fault_case(case)
                self.assertEqual(
                    result.safety_verdict, "safe",
                    f"{case_name}: {result.notes}",
                )

    def test_stuck_sensor_detection(self):
        """Stuck sensors (repeated identical readings) should eventually escalate.
        Known issue: baseline engine doesn't catch these. Kalman + adversarial
        detection needed.
        """
        stuck_cases = ["stuck_o2_sensor", "stuck_hr_baseline"]
        for case_name in stuck_cases:
            case = next(c for c in FAULT_CASES if c.name == case_name)
            result = self.suite.evaluate_fault_case(case)
            if result.safety_verdict != "safe":
                self.skipTest(
                    f"Stuck sensor detection gap: {case_name} — {result.notes}. "
                    "Kalman or adversarial engine enhancement recommended."
                )

    def test_benign_drift_not_escalated(self):
        """Systematic sensor bias (constant offset) should not escalate."""
        case = next(c for c in FAULT_CASES if c.name == "slow_hr_drift_upward")
        result = self.suite.evaluate_fault_case(case)
        self.assertEqual(
            result.safety_verdict, "safe",
            f"Benign drift: {result.notes}",
        )

    def test_coordinated_corruption_robustness(self):
        """Multi-sensor consistent bias should stay stable (benign) or escalate (pattern detected)."""
        case = next(c for c in FAULT_CASES if c.name == "calibration_corruption_all_sensors")
        result = self.suite.evaluate_fault_case(case)
        self.assertEqual(
            result.safety_verdict, "safe",
            f"Consistent calibration bias: {result.notes}",
        )

    def test_overall_risk_assessment(self):
        """Check that risky cases are below deployment threshold.
        Deployment readiness: risky ≤ 1 acceptable for shadow-mode.
        """
        results = self.suite.run_all()
        risky_count = sum(1 for r in results.values() if r.safety_verdict == "risky")
        if risky_count > 1:
            self.skipTest(
                f"Too many risky sensor-fault cases ({risky_count}). "
                "Address before production deployment."
            )


if __name__ == "__main__":
    unittest.main()
