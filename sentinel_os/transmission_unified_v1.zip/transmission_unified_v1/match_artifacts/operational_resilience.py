"""ARENA SCAFFOLDING — stand-in for the Iceberg project's
operational_resilience.py, which is not part of the cage-match kit.

Provides only what sentinel_worker.py / api_server_v2.py import:
setup_logging(name) -> logging.Logger emitting structured JSON and
honoring the project's extra={"extra_data": {...}} convention.

Shared identically by BOTH fighters. Not part of either fighter's code.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone


class JSONFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        out = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        extra = getattr(record, "extra_data", None)
        if extra:
            out["extra_data"] = extra
        return json.dumps(out, default=str)


def setup_logging(name: str) -> logging.Logger:
    lg = logging.getLogger(name)
    if not lg.handlers:
        h = logging.StreamHandler()
        h.setFormatter(JSONFormatter())
        lg.addHandler(h)
    lg.setLevel(logging.INFO)
    lg.propagate = False
    return lg
