"""ARENA SCAFFOLDING — stand-in for the project's api_key_auth.py
(current production auth), which is not part of the cage-match kit.

Implements the seam contract test_L13 exercises:
  * ICEBERG_API_KEYS env = comma-separated "key:name" pairs
  * missing x-api-key header  -> 401
  * wrong key                 -> 403
  * valid key                 -> pass (returns principal name)

Shared identically by BOTH fighters. Not part of either fighter's code.
"""
from __future__ import annotations

import os
from typing import Dict

from fastapi import HTTPException, Request


def _keys() -> Dict[str, str]:
    raw = os.getenv("ICEBERG_API_KEYS", "")
    out: Dict[str, str] = {}
    for pair in raw.split(","):
        pair = pair.strip()
        if not pair:
            continue
        if ":" in pair:
            k, name = pair.split(":", 1)
        else:
            k, name = pair, "unnamed"
        out[k] = name
    return out


def require_api_key(request: Request) -> str:
    keys = _keys()
    supplied = request.headers.get("x-api-key")
    if not supplied:
        raise HTTPException(status_code=401,
                            detail={"error": "missing_api_key"})
    if supplied not in keys:
        raise HTTPException(status_code=403,
                            detail={"error": "invalid_api_key"})
    return keys[supplied]
