"""REFEREE PROBES — Round 1, Fighter R.

Three Round-1 scenarios died on O-only lifecycle counters BEFORE their
core Rule-1 claims (loss / duplication / accounting) could be checked:

  P1  test_enqueue_idempotent_on_job_id  (blocked at counters.enqueued;
      only the queue-depth assertion was unreached)
  P2  test_redis_kill9_loses_nothing_and_pool_recovers (blocked at
      counters.enqueued immediately after broker restart — the entire
      zero-loss / zero-dup verification was unreached)
  P3  test_burst_saturation_accounting_is_exact (blocked at
      counters.enqueued — the exact-accounting verification unreached)

These probes re-run the SAME scenario mechanics through the same adapter
and verify the same core claims using observability Fighter R does have
(state depths + done counter + a claim-log). They exist so the round can
be scored on Rule 1 evidence, not on an inference. They are referee
instruments, not suite modifications; the verbatim suite results stand.
"""
from __future__ import annotations

import os
import shutil
import signal
import subprocess
import tempfile
import threading
import time
import uuid

import redis as redis_lib

from queue_schema import Outcome, TransmissionQueue

CRASH_PORT = 6401


def _wait_ping(port, timeout_s=10.0):
    c = redis_lib.Redis(port=port, socket_connect_timeout=0.5)
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        try:
            if c.ping():
                c.close()
                return
        except redis_lib.exceptions.RedisError:
            time.sleep(0.1)
    raise RuntimeError("redis never came up")


def _start_redis(port, workdir, fsync):
    proc = subprocess.Popen(
        ["redis-server", "--port", str(port), "--dir", workdir,
         "--appendonly", "yes", "--appendfsync", fsync, "--save", "",
         "--logfile", os.path.join(workdir, "redis.log")])
    _wait_ping(port)
    return proc


def probe_1_idempotent_depth(url):
    q = TransmissionQueue(name="p1-" + uuid.uuid4().hex[:8], redis_url=url)
    _, c1 = q.enqueue({"a": 1}, job_id="CA2")
    _, c2 = q.enqueue({"a": 1}, job_id="CA2")
    assert c1 is True and c2 is False
    s = q.stats()
    assert s["pending"] == 1, s          # the unreached depth assertion
    print("P1 idempotent-depth: PASS (created once, pending depth exactly 1)")


def probe_2_kill9(tmp):
    proc = _start_redis(CRASH_PORT, tmp, "always")
    url = f"redis://localhost:{CRASH_PORT}/0"
    try:
        q = TransmissionQueue(name="p2crash", redis_url=url)
        for i in range(100):
            q.enqueue({"i": i}, job_id=f"d{i}")
        for _ in range(20):
            assert q.ack(q.claim("pre-w")) is Outcome.OK
        held = [q.claim("doomed-w", lease_ms=1500) for _ in range(10)]
        assert all(h is not None for h in held)

        os.kill(proc.pid, signal.SIGKILL)
        proc.wait(timeout=5)
        time.sleep(0.3)
        proc = _start_redis(CRASH_PORT, tmp, "always")

        s = q.stats()                      # SAME client object: pool recovers
        assert s["counters"]["completed"] == 20, s
        assert s["pending"] == 70 and s["processing"] == 10, s

        time.sleep(1.6)
        report = q.reap_expired()
        assert len(report["requeued"]) == 10 and not report["dead"], report

        drained, seen = 0, set()
        while True:
            job = q.claim("post-w", wait_timeout_s=0.3)
            if job is None:
                break
            assert job.id not in seen, f"DUPLICATE DELIVERY {job.id}"
            seen.add(job.id)
            assert q.ack(job) is Outcome.OK
            drained += 1
        assert drained == 80, drained
        s = q.stats()
        assert s["counters"]["completed"] == 100          # zero loss, zero dupes
        assert s["pending"] == s["processing"] == s["dead"] == 0, s
        print("P2 kill9: PASS (100 enqueued; kill -9 with 70 pending + 10 "
              "in-flight; restart: 0 lost, 10 reaped, 100/100 completed, "
              "0 duplicate deliveries)")
    finally:
        if proc.poll() is None:
            proc.terminate()
            proc.wait(timeout=5)


def probe_3_burst(url):
    q = TransmissionQueue(name="p3-" + uuid.uuid4().hex[:8], redis_url=url)
    n = 5000
    t0 = time.monotonic()
    for i in range(n):
        q.enqueue({"i": i}, job_id=f"b{i}")
    t_enq = time.monotonic() - t0

    lock = threading.Lock()
    seen = set()
    dupes = []

    def drain(wid):
        while True:
            job = q.claim(wid, lease_ms=60_000, wait_timeout_s=0.3,
                          poll_interval_s=0.005)
            if job is None:
                return
            with lock:
                if job.id in seen:
                    dupes.append(job.id)
                seen.add(job.id)
            q.ack(job)

    t0 = time.monotonic()
    ts = [threading.Thread(target=drain, args=(f"dw{i}",)) for i in range(8)]
    for t in ts:
        t.start()
    for t in ts:
        t.join()
    t_drain = time.monotonic() - t0

    assert not dupes, f"DUPLICATE DELIVERIES: {dupes[:5]}"
    assert len(seen) == n, f"lost jobs: drained {len(seen)} of {n}"
    s = q.stats()
    assert s["counters"]["completed"] == n, s
    assert s["pending"] == s["processing"] == s["scheduled"] == s["dead"] == 0, s
    print(f"P3 burst: PASS ({n} jobs: enqueue {n/t_enq:.0f}/s, drain "
          f"(8 workers) {n/t_drain:.0f} claim+ack/s, 0 lost, 0 duplicated)")


if __name__ == "__main__":
    d_main = tempfile.mkdtemp(prefix="probe-main-")
    d_crash = tempfile.mkdtemp(prefix="probe-crash-")
    main = _start_redis(6402, d_main, "everysec")
    try:
        url = "redis://localhost:6402/0"
        probe_1_idempotent_depth(url)
        probe_2_kill9(d_crash)
        probe_3_burst(url)
        print("ALL PROBES PASS")
    finally:
        main.terminate()
        main.wait(timeout=5)
        shutil.rmtree(d_main, ignore_errors=True)
        shutil.rmtree(d_crash, ignore_errors=True)
